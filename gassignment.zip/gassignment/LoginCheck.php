<?php 
 session_start();
 unset($_SESSION["account"]);
 unset($_SESSION["error"]);
 unset($_SESSION["success"]);
 
 $con = mysqli_connect("localhost","root","","assignment");
 
 $query = "SELECT * FROM userinfo WHERE uname='".$_POST['uname']."' AND password='".$_POST['password']."'";
  
 $sql = $con->query($query);
 
 $n = $sql->num_rows;
  
 if($n > 0)
 {
	$_SESSION["account"] = $_POST['uname'];
	$_SESSION["success"] = "Logged in"; 
	header("Location:Account.php");
	return;
 }
 else
 {	
	$_SESSION["error"] = "**Error: Incorrect Username or Password**";
	header("Location:Account.php");
	return;
 }


 