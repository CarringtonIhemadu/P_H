<?php
	session_start();
	
	$con=mysqli_connect("localhost","root","","assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	else
	{
		$result = mysqli_query($con,"SELECT * FROM userinfo Where uname !='soggycarrot201' and uname !='killian'");
		while($row = mysqli_fetch_array($result))
		{
			if(strtoupper($row['uname'])== strtoupper($_POST['del']))
			{ //admin can delete account
				$sql="DELETE FROM userinfo WHERE upper(uname) like upper('".$_POST['del']."')";
				mysqli_query($con,$sql);
			}
		}
	}
	header("Location:manage.php");
	return;
?>