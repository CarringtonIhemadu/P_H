<?php
	session_start();
	
	$con=mysqli_connect("localhost","root","","assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	else
	{
		$result = mysqli_query($con,"SELECT * FROM userinfo Where uname !='".$_SESSION['account']."'");
		while($row = mysqli_fetch_array($result))
		{
			if($row['uname']== $_SESSION["del"])
			{
				$sql="DELETE FROM userinfo WHERE uname = '".$_SESSION['del']."'";
				mysqli_query($con,$sql);
			}
		}
	}
	unset ($_SESSION["del"]);
	header("Location:manage.php");
	return;
?>