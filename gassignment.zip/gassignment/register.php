<?php
 session_start();
 unset($_SESSION["account"]);
 unset($_SESSION["regError"]);
 unset($_SESSION["success"]);
 
$con=mysqli_connect("localhost","root","","assignment");


$sql="INSERT INTO userinfo (fname, lname, address, email, phonenumber, uname, password) 
VALUES
('$_POST[first]','$_POST[sur]','$_POST[address]','$_POST[email]','$_POST[number]','$_POST[username]','$_POST[password]')";

if(!mysqli_query($con,$sql))
{
	$_SESSION["regError"] = "**Error: Username Taken**";
	header("Location:Account.php");
	return;
}
else
{
	$_SESSION["account"] = $_POST['username'];
	$_SESSION["success"] = "Logged in";
	header("Location:browse.php");
	return;
}
mysqli_close($con);

?>