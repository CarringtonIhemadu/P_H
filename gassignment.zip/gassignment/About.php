<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.4.2.min.js"></script>
		<script type="text/javascript">
			function swapimage1()
			{ //simple gallery
				var currentpicID = document.getElementById('pic1');
				var bigID = document.getElementById('mainpic');
				currentSRC = currentpicID.src;
				bigIDSRC = bigID.src;
				
				currentpicID.src = bigIDSRC;
				bigID.src = currentSRC;
				
			}
			function swapimage2()
			{
				var currentpicID = document.getElementById('pic2');
				var bigID = document.getElementById('mainpic');
				currentSRC = currentpicID.src;
				bigIDSRC = bigID.src;
				
				currentpicID.src = bigIDSRC;
				bigID.src = currentSRC;
				
			}
			function swapimage3()
			{
				var currentpicID = document.getElementById('pic3');
				var bigID = document.getElementById('mainpic');
				currentSRC = currentpicID.src;
				bigIDSRC = bigID.src;
				
				currentpicID.src = bigIDSRC;
				bigID.src = currentSRC;
				
			}
			function swapimage4()
			{
				var currentpicID = document.getElementById('pic4');
				var bigID = document.getElementById('mainpic');
				currentSRC = currentpicID.src;
				bigIDSRC = bigID.src;
				
				currentpicID.src = bigIDSRC;
				bigID.src = currentSRC;
				
			}
		</script>
	</head>
	
	<body>
		<div id="main_div">
			<div id="navigation_bar">
				<nav>
					<ul class="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="About.php" class="selected">About</a></li>
						<li><a href="Contact.php">Contact</a></li>
						<li><a href="browse.php">Browse catalogue</a></li>
						<?php
							if(isset($_SESSION["account"]))
							{
								if($_SESSION['account'] == 'soggycarrot201'|| $_SESSION['account'] == 'killian')
								{
						?>
								<li><a href="Account.php">My Account</a></li>
								<li><a href="manage.php">Manage accounts</a></li>
						<?php
								}
								else
								{
						?>
									<li><a href="Account.php">My Account</a></li>
						<?php
								}
							}
							else if (!isset($_SESSION["account"]))
							{
						?>
								<li><a href="Account.php">Login</a></li>
						<?php
							}
						?>
			
					</ul>
				</nav>
			</div>
			<div id="padding">
				<h1>Our History</h1>
				<br/>
				<br/>
				<br/>
				<div id = "history">
					<p>
					C&K got its start in the 1950s in the homes of neighborhood families. Before they had funding, dedicated community members ran volunteer
					libraries out of their basements, schoolhouses, a barbershop, a plumbing company, a shopping center and a traveling bookmobile.
					Their hard work and passion soon led to an official C&K County Library in the streets of brooklyn new york(shouts out to jay zizzle ma nizzle (i love you man)).
					</p>
					<br/>
					<p>
					Today, C&K County Library serves over two million people from 13 library buildings in the north east corner of kanye's backyard 
					And one thing hasn't changed — the Library staff are helped by 900 volunteers who donate over 50,000 hours of their time each year!
					</p>
				</div>
			</div>
			<div id="gallery">
				<br/>
				<br/>
				<h1>Some Pics </h1>
				<br/>
				<br/>
				<br/>
				<div class="gallery">
					<img id= "pic1" src="outside.jpg" alt="yep" width="600" height="400" onclick="swapimage1()">
				</div>
				<div class="gallery">
					<img id= "pic2" src="pic1.jpg" alt="yep" width="600" height="400" onclick="swapimage2()">
				</div>

				<div class="gallery">
					<img id= "pic3" src="pic2.jpg" alt="yep" width="600" height="400" onclick="swapimage3()">				
				</div>

				<div class="gallery">
					<img id= "pic4" src="pic3.jpg" alt="yep" width="600" height="400" onclick="swapimage4()">
				</div>
			</div>
			<div id="main_picture">
				<img id= "mainpic" src="pic4.jpg" alt="yep" width="800" height="600" >
			</div>
			<div id="location"> 
				<br/>
				<br/>
				<h1>Location</h1>
				<br/>
				<br/>
				<img id="locationpic" src="map.jpg" alt="yep" width="500" height="300">
			</div>
			<a href="Browse.php" class="button">Look through our catalogue</a>
			&nbsp &nbsp <a href="Contact.php" class="button">Contact Us</a>
		</div>
	</body>
</html>