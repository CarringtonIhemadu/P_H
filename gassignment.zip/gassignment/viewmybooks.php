<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<div id="main_div">		
			<?php
				$con=mysqli_connect("localhost","root","","assignment");
				// Check connection
				if (mysqli_connect_errno())
				{
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}
				
				$uname = $_SESSION['account'];
				$result= mysqli_query($con,"SELECT * FROM SALES WHERE uname = '$uname'");
				
				?>
				
				<table id="display">
					<th>
						<td id = "booktitle" ><?php echo "Book Title" ?></td>
						<td id = "Author"><?php echo "Author" ?></td>
						<td id = "Genre"><?php echo "Genre" ?></td>
					</th>
				</table>
				<?php
						
				while($row = mysqli_fetch_array($result))
				{
					$id = $row['bookid'];		
					
					$sql2 = mysqli_query($con,"SELECT * FROM bookstock WHERE  bookid = $id");
					
						
					while($row2 = mysqli_fetch_array($sql2))
					{
						$author= $row2['author'];
						$genre= $row2['genre'];
						$booktitle= $row2['booktitle'];
						
						?>
						<table id="display">
							<tr>
								<td id="bt"><?php echo "$booktitle"; ?></td>
								<td id="auth"><?php echo "$author"; ?></td>
								<td id="genr"><?php echo "$genre"; ?></td>
							</tr>
						</table>
						<?php
					}	
				}
				
				mysqli_close($con);
			?>
		</div>
	</body>
	
</html>