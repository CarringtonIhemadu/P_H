<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<div id="main_div">	
			<?php
				$con=mysqli_connect("localhost","root","","assignment");
				// Check connection
				if (mysqli_connect_errno())
				{
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}
				
				$uname = $_SESSION['account'];
				$result= mysqli_query($con,"SELECT * FROM SALES WHERE uname = '$uname'");
				
				?>
				
				<table id="display">
					<th>
						<td id = "booktitle" ><?php echo "<h3>Book Title</h3>" ?></td>
						<td id = "Author"><?php echo "<h3>Author</h3>" ?></td>
						<td id = "Genre"><?php echo "<h3>Genre</h3>" ?></td>
					</th>
				</table>
				<?php
						
				while($row = mysqli_fetch_array($result))
				{
					$id = $row['bookid'];		
					
					$sql2 = mysqli_query($con,"SELECT * FROM bookstock WHERE  bookid = $id");
					
						
					while($row2 = mysqli_fetch_array($sql2))
					{
						$author= $row2['author'];
						$genre= $row2['genre'];
						$booktitle= $row2['booktitle'];
						
						?>
						<table id="display">
							<tr>
								<td id="bt"><?php echo "<p>$booktitle</p>"; ?></td>
								<td id="auth"><?php echo "<p>$author</p>"; ?></td>
								<td id="genr"><?php echo "<p>$genre</p>"; ?></td>
							</tr>
						</table>
						<?php
					}	
				}
				
				mysqli_close($con);
			?>
			
				<h1> Return Books </h1>
				<form id = "deleteform" action="edit.php" method = "post">
							<br><br>
							<input type="text" name="bn" placeholder="book name" required>
							<br><br>
						<input id = "delete" type="submit" value="return book">
				</form>
				
			<a href="Browse.php" class="button">Back to the library</a>
		</div>
	</body>
	
</html>