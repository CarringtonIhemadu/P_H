<?php
	session_start();
	
	$con=mysqli_connect("localhost","root","","assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	else
	{ //changes users data if value entered
		if(strlen($_POST['un'])>0)
		{
			$sql = "UPDATE userinfo SET uname = '".$_POST['un']."' WHERE uname = '".$_SESSION['account']."'";
			mysqli_query($con,$sql);
		}
		if(strlen($_POST['fn'])>0)
		{
			$sql = "UPDATE userinfo SET fname = '".$_POST['fn']."' WHERE uname = '".$_SESSION['account']."'";
			mysqli_query($con,$sql);
		}
		if(strlen($_POST['sn'])>0)
		{
			$sql = "UPDATE userinfo SET lname = '".$_POST['sn']."' WHERE uname = '".$_SESSION['account']."'";
			mysqli_query($con,$sql);
		}
		if(strlen($_POST['em'])>0)
		{
			$sql = "UPDATE userinfo SET email = '".$_POST['em']."' WHERE uname = '".$_SESSION['account']."'";
			mysqli_query($con,$sql);
		}
		if(strlen($_POST['pn'])>0)
		{
			$sql = "UPDATE userinfo SET phonenumber = '".$_POST['pn']."' WHERE uname = '".$_SESSION['account']."'";
			mysqli_query($con,$sql);
		}
		if(strlen($_POST['add'])>0)
		{
			$sql = "UPDATE userinfo SET address = '".$_POST['add']."' WHERE uname = '".$_SESSION['account']."'";
			mysqli_query($con,$sql);
		}
		if(strlen($_POST['pass'])>0 && strlen($_POST['pass2'])>0 && $_POST['pass'] == $_POST['pass2'])
		{
			$sql = "UPDATE userinfo SET password = '".$_POST['pass']."' WHERE uname = '".$_SESSION['account']."'";
			mysqli_query($con,$sql);
		}
		
		$R1 = mysqli_query($con,"SELECT bookid FROM bookstock where upper(booktitle) = upper('".$_POST['bn']."')");
		while($row = mysqli_fetch_array($R1))
		{
			$id = $row['bookid'];
		}
		
		$uname = $_SESSION['account'];
		
		$result = mysqli_query($con,"SELECT * FROM sales");
		
		while($row = mysqli_fetch_array($result))
		{
			$sql="DELETE FROM sales WHERE bookid = $id and uname= '$uname'";
			mysqli_query($con,$sql);
		}
	}
	header("Location:Account.php");
	return;
?>
