<?php
	session_start();
	session_destroy();
	//logs user out
	$con=mysqli_connect("localhost","root","","assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}		
	unset($_SESSION["account"]);
	header("Location:Account.php");
	return;
?>