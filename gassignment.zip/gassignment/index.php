<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<img id= "banner" src="banner.jpg" alt="yep" width="600" height="400">
		<br>
		<br>
		<h1> Welcome </h1>
		<br>
		<br>
		<div id="welcomepagebuttons">
					<?php
						if(isset($_SESSION["account"]))
						{
					?>
							&nbsp &nbsp <a href="browse.php" class="button">Browse Catalogue</a>
							&nbsp &nbsp &nbsp &nbsp <a href="Account.php" class="button">view your account details</a>
					<?php
						}
						else
						{
					?>
							<a href="Account.php" class="button">login?</a>
							&nbsp &nbsp <a href="browse.php" class="button">Continue as a guest?</a>
							&nbsp &nbsp <a href="Account.php" class="button">Create an account?</a>
					<?php
						}
					?>
		</div>
	</body>
	
</html>