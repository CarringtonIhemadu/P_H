<?php
 session_start();
 
$con=mysqli_connect("localhost","root","","assignment");
//updates users info
$query1="SELECT * FROM userinfo WHERE uname = '".$_POST['uname']."'";
$query2="UPDATE userinfo SET password = '".$_POST['pass1']."' WHERE uname = '".$_POST['uname']."' ";

$sql = $con->query($query2);

$sql = $con->query($query1);
//check if update was successful or not
$n = $sql->num_rows;
  
 if($n > 0)
 {
	header("Location:Account.php");
	return;
 }
 else
 {	
	$_SESSION["error"] = "**Error: Incorrect Username or Password**";
	header("Location:forgot.php");
	return;
 } 

mysqli_close($con);

?>