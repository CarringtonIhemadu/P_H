<?php
	session_start();
	
	$con=mysqli_connect("localhost","root","","assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	else
	{ //gets bookid
		$R1 = mysqli_query($con,"SELECT bookid FROM bookstock where upper(booktitle) = upper('".$_POST['bn']."')");
		while($row = mysqli_fetch_array($R1))
		{
			$id = $row['bookid'];
		}
		
		$uname = $_SESSION['account'];
		
		$result = mysqli_query($con,"SELECT * FROM sales");
		
		while($row = mysqli_fetch_array($result))
		{ //returns book
			$sql="DELETE FROM sales WHERE bookid = $id and uname= '$uname'";
			mysqli_query($con,$sql);
		}
	}
	header("Location:viewmybooks.php");
	return;
?>
