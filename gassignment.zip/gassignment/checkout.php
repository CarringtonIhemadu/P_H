<?php
	session_start();
	//establishes connection
	$con=mysqli_connect("localhost","root","","assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	else
	{   //get bookid
		$result = mysqli_query($con,"SELECT bookid FROM bookstock where upper(booktitle) = upper('".$_POST['booktitle']."')");
		$uname = $_SESSION['account'];
		
		while($row = mysqli_fetch_array($result))
		{
			$id = $row['bookid'];
			//insert into table
			$sql = "INSERT INTO sales (uname,bookid) VALUES ('$uname',$id)";
			mysqli_query($con,$sql);
			//takes 1 away from stock_level
			$query = "UPDATE bookstock SET (stock_level = stock_level + -1) where upper(booktitle) = upper('".$_POST['booktitle']."')";
			$sql = $con->query($query);
		}
	}
	mysqli_close($con);
	header("Location:viewmybooks.php");
?>