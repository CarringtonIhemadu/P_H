<?php
	session_start();
	
	$con=mysqli_connect("localhost","root","","assignment");
	
	// Check connection
	if (mysqli_connect_errno())
	{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	else
	{
		$result = mysqli_query($con,"SELECT bookid FROM bookstock where booktitle ='".$_POST['booktitle']."'");
		$uname = $_SESSION['account'];
		
		while($row = mysqli_fetch_array($result))
		{
			$id = $row['bookid'];
			
			$sql = "INSERT INTO sales (uname,bookid) VALUES ('$uname',$id)";
			mysqli_query($con,$sql);
		}
	}
	header("Location:viewmybooks.php");
	mysqli_close($con);
?>
