<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<div id="main_div">
			<div id="navigation_bar">
				<nav>
					<ul class="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="About.php">About</a></li>
						<li><a href="Contact.php" class="selected">Contact</a></li>
						<li><a href="browse.php">Browse catalogue</a></li>
						<?php
							if(isset($_SESSION["account"]))
							{
								if($_SESSION['account'] == 'soggycarrot201'|| $_SESSION['account'] == 'killian')
								{
						?>
								<li><a href="Account.php">My Account</a></li>
								<li><a href="manage.php">Manage accounts</a></li>
						<?php
								}
								else
								{
						?>
									<li><a href="Account.php">My Account</a></li>
						<?php
								}
							}
							else if (!isset($_SESSION["account"]))
							{
						?>
								<li><a href="Account.php">Login</a></li>
						<?php
							}
						?>
					</ul>
				</nav>
			</div>
			<div id="Text">
				<h1>Contact Us!</h1>

				Here at C&K , we believe that communication with customers
				is key to success, so you can reach us from all of the best social media
				web sites, as well as by phone, email or by dropping in if you're around.
				So get in touch! we'd love to help. 
				<br><br><br>
				<h3>Phone Number: 01 345 1980</h3> 
				
				<h3>Email: C&K@gmail.com</h3>
				
				<h3>Social Media:
				<a href ="https://www.facebook.com/"><img src="fb.jpg" style="width:50px; height: 50px; border-radius: 25px;"></a>
					
				<a href ="https://www.instagram.com/"><img src="insta.jpg" style="width:50px; height: 50px; border-radius: 25px;"></a>
					
				<a href ="https://www.twitter.com/"><img src="tweet.jpg" style="width:50px; height: 50px; border-radius: 25px;">
				</h3></a>
			</div>
		</div>
	</body>
</html>