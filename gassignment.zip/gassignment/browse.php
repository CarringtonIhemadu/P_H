<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.4.2.min.js"></script>
		<script type="text/javascript">
			function classics()
			{//displaying books by filters
				document.getElementById('classics').style.display ='inline-block';
				document.getElementById('kids').style.display ='none';
				document.getElementById('teen').style.display ='none';
				document.getElementById('scifi').style.display ='none';
				document.getElementById('horror').style.display ='none';
				document.getElementById('action').style.display ='none';
				document.getElementById('comedy').style.display ='none';
			}
			function kids()
			{
				document.getElementById('classics').style.display ='none';
				document.getElementById('kids').style.display ='inline-block';
				document.getElementById('teen').style.display ='none';
				document.getElementById('scifi').style.display ='none';
				document.getElementById('horror').style.display ='none';
				document.getElementById('action').style.display ='none';
				document.getElementById('comedy').style.display ='none';
			}
			function teen()
			{
				document.getElementById('classics').style.display ='none';
				document.getElementById('kids').style.display ='none';
				document.getElementById('teen').style.display ='inline-block';
				document.getElementById('scifi').style.display ='none';
				document.getElementById('horror').style.display ='none';
				document.getElementById('action').style.display ='none';
				document.getElementById('comedy').style.display ='none';
			}
			function scifi()
			{
				document.getElementById('classics').style.display ='none';
				document.getElementById('kids').style.display ='none';
				document.getElementById('teen').style.display ='none';
				document.getElementById('scifi').style.display ='inline-block';
				document.getElementById('horror').style.display ='none';
				document.getElementById('action').style.display ='none';
				document.getElementById('comedy').style.display ='none';
			}
			function horror()
			{
				document.getElementById('classics').style.display ='none';
				document.getElementById('kids').style.display ='none';
				document.getElementById('teen').style.display ='none';
				document.getElementById('scifi').style.display ='none';
				document.getElementById('horror').style.display ='inline-block';
				document.getElementById('action').style.display ='none';
				document.getElementById('comedy').style.display ='none';
			}
			function action()
			{
				document.getElementById('classics').style.display ='none';
				document.getElementById('kids').style.display ='none';
				document.getElementById('teen').style.display ='none';
				document.getElementById('scifi').style.display ='none';
				document.getElementById('horror').style.display ='none';
				document.getElementById('action').style.display ='inline-block';
				document.getElementById('comedy').style.display ='none';
			}
			function comedy()
			{
				document.getElementById('classics').style.display ='none';
				document.getElementById('kids').style.display ='none';
				document.getElementById('teen').style.display ='none';
				document.getElementById('scifi').style.display ='none';
				document.getElementById('horror').style.display ='none';
				document.getElementById('action').style.display ='none';
				document.getElementById('comedy').style.display ='inline-block';
			}
			function all()
			{
				document.getElementById('classics').style.display ='inline-block';
				document.getElementById('kids').style.display ='inline-block';
				document.getElementById('teen').style.display ='inline-block';
				document.getElementById('scifi').style.display ='inline-block';
				document.getElementById('horror').style.display ='inline-block';
				document.getElementById('action').style.display ='inline-block';
				document.getElementById('comedy').style.display ='inline-block';
			}
		
		</script>
	</head>
	
	<body>
		<div id="main_div">
			<div id="navigation_bar">
				<nav>
					<ul class="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="About.php">About</a></li>
						<li><a href="Contact.php">Contact</a></li>
						<li><a href="browse.php" class="selected">Browse catalogue</a></li>
						<?php
							if(isset($_SESSION["account"]))
							{
								if($_SESSION['account'] == 'soggycarrot201' || $_SESSION['account'] == 'killian')
								{
						?>
								<li><a href="Account.php">My Account</a></li>
								<li><a href="manage.php">Manage accounts</a></li>
						<?php
								}
								else
								{
						?>
									<li><a href="Account.php">My Account</a></li>
						<?php
								}
							}
							else if (!isset($_SESSION["account"]))
							{
						?>
								<li><a href="Account.php">Login</a></li>
						<?php
							}
						?>
					</ul>
				</nav>
			</div>
			
			<div class="dropdown">
				<button class="dropbtn">Books Per Page</button>
				<div class="dropdown-content">
					<a href="#" onclick= "classics()">classics</a>
					<a href="#" onclick= "kids()">kids books</a>
					<a href="#" onclick= "teen()">Adolescent books</a>
					<a href="#" onclick= "scifi()">Sci-fi</a>
					<a href="#" onclick= "horror()">Horror</a>
					<a href="#" onclick= "action()">Action</a>
					<a href="#" onclick= "comedy()">Comedy</a>
					<a href="Browse.php">Display all</a>
				</div>
			</div>
			
			<!-- classics -->

			<div id = "classics" class = "row" style="display:block;">
					<a href = "#checkout"><img id="rowimg"src="in_search_of_lost_time.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="don_quixote.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="ulysses.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="the_great_gatsby.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="moby_dick.jpg" width="120" height="200"></a>
			</div>
			
			<!-- kidsbooks -->
			
			<div id = "kids" class = "row" style="display:block;">
					<a href = "#checkout"><img id="rowimg" src="wherethewildthingsare.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg" src="thesnowyday.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg" src="goodnightmoon.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg" src="thegivingtree.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg" src="tuesday.jpg" width="120" height="200"></a>
			</div>
			
			<!-- teenbooks -->
			<div id = "teen" class = "row" style="display:block;">
					<a href = "#checkout"><img id="rowimg"src="holes.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="awrinkleintime.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="matilda.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="thegiver.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="theoutsiders.jpg" width="120" height="200"></a>
			</div>
			
			<!-- scifi -->
			
			<div id = "scifi" class = "row" style="display:block;">
					<a href = "#checkout"><img id="rowimg"src="1984.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="allthebirdsinthesky.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="amatka.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="anathem.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="binti.jpg" width="120" height="200"></a>
			</div>
			
			<!-- horror -->
			
			<div id = "horror" class = "row" style="display:block;">
					<a href = "#checkout"><img id="rowimg"src="it.jp.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="theshinning.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="chalk.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="shutter.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="thedeathhouse.jpg" width="120" height="200"></a>
			</div>
			
			<!-- action -->
			
			<div id = "action" class = "row" style="display:block;">
					<a href = "#checkout"><img id="rowimg"src="divergent.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="endergame.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="bodygaurd.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="isurvived.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="theshadowproject.jpg" width="120" height="200">
			</div>
			
			<!-- comedy -->
			
			<div id = "comedy" class = "row" style="display:block;">
					<a href = "#checkout"><img id="rowimg"src="crazyrichasians.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="norm.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="thebolds.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="thestupidestangel.jpg" width="120" height="200"></a>
					<a href = "#checkout"><img id="rowimg"src="gangstagranny.jpg" width="120" height="200"></a>
			</div>
			<br>
			<br>
			<br>
			<form id = "loginform" action="checkout.php" method = "post">
				<br>
				<br>
				<?php
					if(isset($_SESSION["account"]))
					{ //borrowing a book
						echo '<input type="text" name="booktitle" placeholder=" book title " required>';
						echo '<br><br><br>';
						echo '<input id = "checkout" type="submit" value="Take out book?">';
					}
					else
					{
						echo '<a href="Account.php" class="button">*Please log in first*</a>';
					}
				?>
				
			</form>
		</div>
	</body>
</html>