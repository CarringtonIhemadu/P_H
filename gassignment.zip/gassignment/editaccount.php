<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<div id="main_div">
			<div id="navigation_bar">
				<nav>
					<ul class="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="About.php">About</a></li>
						<li><a href="Contact.php">Contact</a></li>
						<li><a href="browse.php">Browse catalogue</a></li>
						<?php
							if(isset($_SESSION["account"]))
							{//partial displays if not logged in
								if($_SESSION['account'] == 'soggycarrot201'|| $_SESSION['account'] == 'killian')
								{
						?>
								<li><a href="Account.php">My Account</a></li>
								<li><a href="manage.php">Manage accounts</a></li>
						<?php
								}
								else
								{
						?>
									<li><a href="Account.php">My Account</a></li>
						<?php
								}
							}
							else if (!isset($_SESSION["account"]))
							{
						?>
								<li><a href="Account.php">Login</a></li>
						<?php
							}
						?>
					</ul>
				</nav>
			</div>
			<div id = "editdetails">
				<form action="change.php" method = "post">
					<input type="text" name="un" placeholder="Username">
					&nbsp &nbsp &nbsp
					<input type="submit" value="change">
					<br><br>
					<input type="text" name="fn" placeholder="First name">
					&nbsp &nbsp &nbsp
					<input type="submit" value="change">
					<br><br>
					<input type="text" name="sn" placeholder="Second name">
					&nbsp &nbsp &nbsp
					<input type="submit" value="change">
					<br><br>
					<input type="text" name="pn" placeholder="Phone Number">
					&nbsp &nbsp &nbsp
					<input type="submit" value="change">
					<br><br>
					<input type="text" name="em" placeholder="Email address">
					&nbsp &nbsp &nbsp
					<input type="submit" value="change">
					<br><br>
					<input type="text" name="add" placeholder="Address">
					&nbsp &nbsp &nbsp
					<input type="submit" value="change">
					<br><br>
					<input type="password" name="pass" placeholder="Password">
					&nbsp &nbsp &nbsp
					<input type="password" name="pas2" placeholder="re enter Password">
					&nbsp &nbsp &nbsp
					<input type="submit" value="change">
					<br><br>
				</form>
			</div>
		</div>
	</body>
</html>