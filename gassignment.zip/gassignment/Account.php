<?php
	session_start();
?>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<div id="main_div">
			<div id="navigation_bar">
				<nav>
					<ul class="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="About.php">About</a></li>
						<li><a href="Contact.php">Contact</a></li>
						<li><a href="browse.php">Browse catalogue</a></li>
						<?php
							if(isset($_SESSION["account"]))
							{
								if($_SESSION['account'] == 'soggycarrot201'|| $_SESSION['account'] == 'killian')
								{
						?>
								<li><a href="Account.php" class="selected">My Account</a></li>
								<li><a href="manage.php">Manage accounts</a></li>
						<?php
								}
								else
								{
						?>
									<li><a href="Account.php">My Account</a></li>
						<?php
								}
							}
							else if (!isset($_SESSION["account"]))
							{
						?>
								<li><a href="Account.php" class="selected">Login</a></li>
						<?php
							}
						?>
					</ul>
				</nav>
			</div>
			<?php
				if(!isset($_SESSION["account"]))
				{
			?>
			<div id="login">
				<h1>Log in!</h1>
				<?php
					if(isset($_SESSION["error"]))
					{
						echo ("<p style='color:red'>".$_SESSION["error"]."</p>");
						unset($_SESSION["error"]);
					}
				?>
				<p>Enter your details to access your account.<p>
				
				<form id = "loginform" action="LoginCheck.php" method = "post">
					<input type="text" name="uname" placeholder=" Username" required>
					<br>
					<br>
					<input type="password" name="password" placeholder=" Password" required>
					<br>
					<br>
					<input type="submit" value="Login">
				</form>
				<br>
				<br>
			</div>
			<br>
			<br>
			<br>
			<div id="SignUp">
				<br>
				<br>
				<h1>Sign Up!</h1>
				<?php
					if(isset($_SESSION["regError"]))
					{
						echo ("<p style='color:red'>".$_SESSION["regError"]."</p>");
						unset($_SESSION["regError"]);
					}
				?>
				<p>New to us? Create an account here!</p>
				<form action="register.php" method = "post">
					<input type="text" name="first" placeholder=" First Name" required>
					<br>
					<br>
					<input type="text" name="sur" placeholder=" Last Name" required>
					<br>
					<br>
					<input type="text" name="address" placeholder=" Address" required>
					<br>
					<br>
					<input type="email" name="email" placeholder=" Email" required>
					<br>
					<br>
					<input type="text" name="number" placeholder=" Phone Number" required>
					<br>
					<br>
					<input type="text" name="username" placeholder=" Username" required>
					<br>
					<br>
					<input type="password" name="password" placeholder=" Password" required>
					<br><br>
					<input type="submit" value="Sign Up">
				</form>
				<br>
				<br>
			</div>
			<?php
				}
				else if ($_SESSION['account'] == 'soggycarrot201')
				{
					echo '<div id= "loggedon">';
					echo "<h1>Welcome Administrator!</h1>";
					echo '</div>';
					
					echo '<div id= "Details">';
						$con=mysqli_connect("localhost","root","","assignment");
						// Check connection
						if (mysqli_connect_errno())
						{
						echo "Failed to connect to MySQL: " . mysqli_connect_error();
						}

						$result = mysqli_query($con,"SELECT * FROM userinfo Where uname='".$_SESSION['account']."'");


						while($row = mysqli_fetch_array($result))
						{
							echo "<tr>";
							echo "<br>";
							echo "<span>Username: </span>"."<td>" . $row['uname'] . " </td>";
							echo "<br><br>";
							echo "<span>Name: </span>"."<td>" . $row['fname'] . " </td>";
							echo "<td> " . $row['lname'] . "</td>";
							echo "<br><br>";
							echo "<span>Email Address: </span>"."<td>" . $row['email'] . "</td>";
							echo "<br><br>";
							echo "<span>Phone Number: </span>"."<td> 0" . $row['phonenumber'] . "</td>";
							echo "<br><br>";
							echo "<span>Address: </span>". $row['address'];

							echo "</tr>";
						}
						mysqli_close($con);
						
						echo "<br><br><br>";
						echo "<a href=\"Browse.php\" class=\"button\">browse library now</a>";
						echo "&nbsp &nbsp &nbsp &nbsp &nbsp<a href=\"Checkout.php\" class=\"button\">View books that youve taken out</a>";
						echo "&nbsp &nbsp &nbsp &nbsp &nbsp<a href=\"logout.php\" class=\"button\">Log out</a>";
						echo "&nbsp &nbsp <a href=\"manage.php\" class=\"button\">View all users</a>";
						echo "<br><br><br><br>";
					echo '</div>';
				}
				
				else
				{
					echo '<div id= "loggedon">';
					echo "<h1>Welcome " . $_SESSION["account"] . "!</h1>";
					echo '</div>';
					
					echo '<div id= "Details">';
						$con=mysqli_connect("localhost","root","","assignment");
						// Check connection
						if (mysqli_connect_errno())
						{
						echo "Failed to connect to MySQL: " . mysqli_connect_error();
						}

						$result = mysqli_query($con,"SELECT * FROM userinfo Where uname='".$_SESSION['account']."'");


						while($row = mysqli_fetch_array($result))
						{
							echo "<tr>";
							echo "<br>";
							echo "<span>Username: </span>"."<td>" . $row['uname'] . " </td>";
							echo "<br><br>";
							echo "<span>Name: </span>"."<td>" . $row['fname'] . " </td>";
							echo "<td> " . $row['lname'] . "</td>";
							echo "<br><br>";
							echo "<span>Email Address: </span>"."<td>" . $row['email'] . "</td>";
							echo "<br><br>";
							echo "<span>Phone Number: </span>"."<td> 0" . $row['phonenumber'] . "</td>";
							echo "<br><br>";
							echo "<span>Address: </span>". $row['address'];

							echo "</tr>";
						}
						mysqli_close($con);
						
						echo "<br><br><br>";
						echo "<a href=\"Browse.php\" class=\"button\">browse library now</a>";
						echo "&nbsp &nbsp <a href=\"viewmybooks.php\" class=\"button\">View books that youve taken out</a>";
						echo "&nbsp &nbsp <a href=\"logout.php\" class=\"button\">Log out</a>";
						echo "<br><br><br><br>";
					echo '</div>';
				}
			?>	
		</div>
	</body>
</html>