<?php
	session_start();
?>
<html>
	<head>
		<title>Main page</title>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<div id="main_div">
			<div id="navigation_bar">
				<nav>
					<ul class="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="About.php">About</a></li>
						<li><a href="Contact.php">Contact</a></li>
						<li><a href="browse.php">Browse catalogue</a></li>
						<li><a href="Account.php">Login</a></li>
					</ul>
				</nav>
			</div>
	
			<div id="login">
				<h1>Forgot password?</h1>
				<?php
					if(isset($_SESSION["error"]))
					{ //prints out error message
						echo ("<p style='color:red'>".$_SESSION["error"]."</p>");
						unset($_SESSION["error"]);
					}
				?>
				<p>Enter your new password<p>
					
				<form id = "loginform" action = "reset.php" method = "post">
					<input type="text" name="uname" placeholder=" Please enter username" required>
					<br>
					<br>
					<input type="password" name="pass1" placeholder=" Please enter password" required>
					<br>
					<br>
					<input type="password" name="pass2" placeholder=" Please repeat password" required>
					<br>
					<br>
					<input type="submit" value="Change password">
				</form>
				<br>
				<br>
			</div>
		</div>
	</body>
</html>
