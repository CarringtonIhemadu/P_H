-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2018 at 05:29 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookstock`
--

CREATE TABLE `bookstock` (
  `booktitle` varchar(70) NOT NULL,
  `author` varchar(70) NOT NULL,
  `genre` varchar(70) NOT NULL,
  `stock_level` int(70) NOT NULL,
  `bookid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookstock`
--

INSERT INTO `bookstock` (`booktitle`, `author`, `genre`, `stock_level`, `bookid`) VALUES
('In search of lost time', 'Marcel Proust', 'Classics', 4, 1),
('Don Quixote', 'Miguel De Cervantes', 'Classics', 4, 2),
('Ulysses', 'James Joyce', 'Classics', 4, 3),
('The great gatsby', 'F.Scott Fitzgerald', 'Classics', 4, 4),
('Moby Dick', 'Herman Melville', 'Classics', 4, 5),
('Where the wild things are', 'Maurice Sendak', 'Kids', 4, 6),
('The snowy day', 'Ezra jack keats', 'Kids', 4, 7),
('Goodnight moon', 'Margaret Wise Brown', 'Kids', 4, 8),
('The giving tree', 'Shel Silverstein', 'Kids', 4, 9),
('Tuesday', 'David Wiesner', 'Kids', 4, 10),
('Holes', 'Louis Sachar', 'Teen', 4, 11),
('A wrinkle in time', 'Madeleine Lengle', 'Teen', 4, 12),
('Matilda', 'Roald Dahl', 'Teen', 4, 13),
('The giver', 'Lois Lowry', 'Teen', 4, 14),
('The outsiders', 'S.E. Hinton', 'Teen', 4, 15),
('1984', 'George Orwell', 'Scifi', 4, 16),
('All the birds in the sky', 'Charlie Jane Anders', 'Scifi', 4, 17),
('Amatka', 'Karin Tidbeck', 'Scifi', 4, 18),
('Anathem', 'Neal Stephenson', 'Scifi', 4, 19),
('Binti', 'Nnedi Okorafor', 'Scifi', 4, 20),
('IT', 'Stephen King', 'Horror', 4, 21),
('The shining', 'Stephen King', 'Horror', 4, 22),
('Chalk', 'Paul Cornell', 'Horror', 4, 23),
('Shutter', 'Courtney Alameda', 'Horror', 4, 24),
('The death house', 'Stephen King', 'Horror', 4, 25),
('Divergent', 'Veronica Roth', 'Action', 4, 26),
('Enders Game', 'Orson Scott Card', 'Action', 4, 27),
('Bodyguard recruit', 'Chris Bradford', 'Action', 4, 28),
('I survived', 'Lauren Tarshis', 'Action', 4, 29),
('The shadow project', 'Scott Mariani', 'Action', 4, 30),
('Crazy rich asians', 'Kevin Kwan', 'Comedy', 4, 31),
('Norm Macdonal', 'Louis Ck', 'Comedy', 4, 32),
('The bolds', 'Julian Clary', 'Comedy', 4, 33),
('The stupidest angel', 'Christopher  Moore', 'Comedy', 4, 34),
('Gangsta granny', 'David Walliams', 'Action', 4, 35);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `uname` varchar(70) NOT NULL,
  `bookid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`uname`, `bookid`) VALUES
('swag1', 4),
('sw', 11),
('sw', 4),
('killian', 11),
('killian', 4);

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `fname` varchar(70) NOT NULL,
  `lname` varchar(70) NOT NULL,
  `address` varchar(70) NOT NULL,
  `email` varchar(70) NOT NULL,
  `phonenumber` int(10) NOT NULL,
  `uname` varchar(70) NOT NULL,
  `password` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`fname`, `lname`, `address`, `email`, `phonenumber`, `uname`, `password`) VALUES
('Killian', 'Waldron', '7 valley walk', 'C16371656@mydit.ie', 833928421, 'killian', 'Pass1'),
('carrington', 'ihemadu', '206 Avondale park, mulhuddart, dublin 15', 'C16341401@mydit.ie', 834623698, 'soggycarrot201', 'thursday08'),
('Sadhbh', 'Wilcoxson', 'High street', 'hi@hotmail.com', 833922222, 'sw', 'Pass1'),
('my', 'rah', 'lusk', 'mymy@ymail.com', 1234567894, 'swag1', 'mymy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookstock`
--
ALTER TABLE `bookstock`
  ADD PRIMARY KEY (`bookid`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD KEY `uname` (`uname`),
  ADD KEY `bookid` (`bookid`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`uname`),
  ADD UNIQUE KEY `uname` (`uname`),
  ADD UNIQUE KEY `phonenumber` (`phonenumber`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`uname`) REFERENCES `userinfo` (`uname`),
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`bookid`) REFERENCES `bookstock` (`bookid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
