<?php
	session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<link id="pagestyle" rel="stylesheet" type="text/css" href="Style.css">
	</head>
	
	<body>
		<div id="main_div">
			<div id="navigation_bar">
				<nav>
					<ul class="nav">
						<li><a href="index.php">Home</a></li>
						<li><a href="About.php">About</a></li>
						<li><a href="Contact.php">Contact</a></li>
						<li><a href="browse.php">Browse catalogue</a></li>
						<?php
							if($_SESSION['account'] == 'soggycarrot201'|| $_SESSION['account'] == 'killian')
							{
						?>
								<li><a href="Account.php">My Account</a></li>
								<li><a href="manage.php" class="selected">Manage accounts</a></li>
						<?php
							}
							else if(isset($_SESSION["account"]))
							{
						?>
								<li><a href="Account.php">My Account</a></li>
						<?php
							}
							else if (!isset($_SESSION["account"]))
							{
						?>
								<li><a href="Account.php"Login</a></li>
						<?php
							}
						?>
					</ul>
				</nav>
			</div>
			<?php
				if ($_SESSION['account'] == 'soggycarrot201')
				{
					echo '<div id= "loggedon">';
					echo '<br><br>';
					echo "<h1>list of all accounts</h1>";
					echo '</div>';
					
					echo '<div id= "accounts">';
						$con=mysqli_connect("localhost","root","","assignment");
						// Check connection
						if (mysqli_connect_errno())
						{
						echo "Failed to connect to MySQL: " . mysqli_connect_error();
						}

						$result = mysqli_query($con,"SELECT * FROM userinfo Where uname !='".$_SESSION['account']."'");


						while($row = mysqli_fetch_array($result))
						{
							echo "<tr>";
							echo "<span>Username: </span>"."<td>" . $row['uname'] . " </td>";
							echo "<br>";
							echo "<span>Name: </span>"."<td>" . $row['fname'] . " </td>";
							echo "<td> " . $row['lname'] . "</td>";
							echo "<br>";
							echo "<span>Email Address: </span>"."<td>" . $row['email'] . "</td>";
							echo "<br>";
							echo "<span>Phone Number: </span>"."<td> 0" . $row['phonenumber'] . "</td>";
							echo "<br>";
							echo "<td><span>Address: </span>". $row['address']."</td>";
							echo "</tr>";
							echo "<br>";
							echo "<a href=\"delete.php\" class=\"button\">Delete account</a>";
							$_SESSION["del"]= $row['uname'];
							echo "&nbsp &nbsp &nbsp";
							echo "<a href=\"#\" class=\"button\">View borrowed items</a>";
							echo "<br><br><br>";
						}
						
						mysqli_close($con);
						
					echo '</div>';
				}
			?>
		</div>
	</body>
</html>